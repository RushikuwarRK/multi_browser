// Import necessary modules
const express = require('express');
const path = require('path');
const { createProxyMiddleware } = require('http-proxy-middleware'); // Correct way to import
const cors = require('cors'); // Import CORS middleware

const app = express();
const port = 5000;  // Proxy server will run on this port

// Enable CORS to allow cross-origin requests
app.use(cors());

// Serve static files (frontend assets) from the 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// Proxy YouTube embed requests to the actual YouTube server
app.use('/youtube', createProxyMiddleware({
  target: 'https://www.youtube.com', // Target YouTube for embedding
  changeOrigin: true,  // Changes the origin of the request to the target URL
  pathRewrite: {
    '^/youtube': '',  // Remove the '/youtube' prefix in the URL
  },
  onProxyReq: (proxyReq, req, res) => {
    console.log(`Proxying request for ${req.url}`);
  },
  onError: (err, req, res) => {
    console.error('Error in proxying request:', err);
    res.status(500).send('Something went wrong with the proxy');
  }
}));

// Start the proxy server
app.listen(port, () => {
  console.log(`Proxy server running on http://localhost:${port}`);
});
